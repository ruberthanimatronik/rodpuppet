Below follows the recommended print settings for parts in each section


ARMS
Recommended print settings for all parts that are going to be visible (hands/feet) are simply:
as good as you want it. When printed using an FDM printer I
typically print at 0.1mm layer height and little to no infill, using add:north textura filament.

Supports are recommended only for the parts R/L_arm_lower. 

The rest doesn't really matter, I print at 0.2mm or 0.3mm with 10-15% infill. PETG is recommended for durability.

BODY
Visual quality doesn't matter here either, I print these parts at 0.2mm or 0.3mm with 10-15% infill using PETG.

HEAD
Visual quality doesn't matter here either, except for the part labelled outerneck. 
Print the outerneck since as good as you'd like since it's going to be visible.

I print the rest of the parts at 0.2mm or 0.3mm with 10-15% infill using PETG. 

CONTROLLER
Visual quality doesn't matter here either, I print these parts at 0.2mm or 0.3mm with 15-20% infill using PETG.
